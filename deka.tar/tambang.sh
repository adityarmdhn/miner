#!/bin/sh
./deka -a ethash -o stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -u 3JxxhYYgXRYDbG5DiRWsDLbumRpsB7TGMc -p x -w Deka --low-load 1
